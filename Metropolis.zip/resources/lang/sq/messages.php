<?php

// resources/lang/en/messages.php

return [
    'welcome' => 'Mirësevini në aplikacionin tonë'
];