<?php $__env->startSection('title','Shiko Pacient'); ?>
<?php $__env->startSection('pacient','active'); ?>
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-5 m-auto d-flex justify-content-center ">
                <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
            </div>
        <div class="col-lg-7">
            <div class="p-5">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Të dhënat e pacientit</h1>
                </div>
                <table class="table table-striped ">
                        <tbody>
                            <tr>
                                <th>Emri:</th>
                                <td scope="row"><?php echo e($pacient->first_name); ?></td>
                            </tr>
                            <tr>
                                <th>Emri i prindit:</th>
                                <td scope="row"><?php echo e($pacient->fathers_name); ?></td>
                            </tr>
                           
                            <tr>
                                <th>Mbiemri:</th>
                                <td scope="row"><?php echo e($pacient->last_name); ?></td>
                            </tr>
                            <tr>
                                    <th>Numri Personal:</th>
                                    <td scope="row"><?php echo e($pacient->personal_number); ?></td>
                                </tr>
                            <tr>
                                <th>Gjinia:</th>
                                <td scope="row"><?php echo e($pacient->gender); ?> </td>
                            </tr>
                            <tr>
                                    <th>Data e lindjes:</th>
                                    <td scope="row"><?php echo e($pacient->date_of_birth); ?></td>
                                </tr>
                               
                                <tr>
                                    <th>Adresa:</th>
                                    <td scope="row"><?php echo e($pacient->address); ?></td>
                                </tr>
                                <tr>
                                    <th>Vendbanimi:</th>
                                    <td scope="row"><?php echo e($pacient->residence); ?> </td>
                                </tr>
                                <tr>
                                        <th>Qyteti:</th>
                                        <td scope="row"><?php echo e($pacient->city); ?> </td>
                                    </tr>
                                    <tr>
                                            <th>Telefoni:</th>
                                            <td scope="row"><?php echo e($pacient->phone); ?> </td>
                                        </tr>
                                        <tr>
                                                <th>Email:</th>
                                                <td scope="row"><?php echo e($pacient->email); ?> </td>
                                            </tr>
                        </tbody>
                    </table>
                <hr>
                <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                        <a href="/pacient/<?php echo e($pacient->id); ?>/edit"  class="btn btn-circle btn-primary"><i class="fa fa-pen"></i></a>
                        <button class="btn btn-circle btn-danger" data-toggle="modal" data-target="#fshijModal<?php echo e($pacient->id); ?>"><i class="fa fa-trash"></i></button>
                        <div class="modal fade" id="fshijModal<?php echo e($pacient->id); ?>" tabindex="-1" role="dialog" aria-labelledby="fshijModalLabel<?php echo e($pacient->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="fshijModalLabel<?php echo e($pacient->id); ?>">Fshij Pacientit</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                        
                                      <form id="form<?php echo e($pacient->id); ?>" class="d-inline" method="POST" action="<?php echo e(route('pacient.destroy',$pacient->id)); ?>" accept-charset="UTF-8">
                                          <?php echo e(csrf_field()); ?>

                                          <input name="_method" type="hidden" value="DELETE">
                                          <div class="custom-control custom-checkbox small">
                                              <input type="checkbox"  name="data"  class="custom-control-input" id="data">
                                          <label class="custom-control-label" for="data">Fshini të dhënat e Pacientit?</label>
                                            </div>
                                         
                                  </div>
                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-circle btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i></button>
                                     
                                         
                                          <button type="submit" form="form<?php echo e($pacient->id); ?>" class="btn btn-circle btn-danger"><i class="fa fa-trash"></i></button>
                                      </form>
                                      
                                  </div>
                                </div>
                            </div>
                        </div> 
            </div>
          </div>

         
        </div>
        <div class="card-body">
                <div class="text-center">
                        <h1 class="h4 text-gray-900 mb-4">Historiku</h1>
                    </div>
                <table class="table table-bordered"  width="100%" cellspacing="0">
                    <h3>Terminet</h3> <hr>
                        <thead class="bg-dark text-light">
                          <tr>
                            <th>Pacienti</th>
                            <th>Dentisti</th>
                            <th>Data</th>
                            <th>Ora</th>
                            <th>Menaxhimi</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if(count($appointments)>0): ?>  
                          <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e(App\Pacient::getPacient($appointment->pacient_id)); ?></td>
                            <td><?php echo e(App\User::getUser($appointment->user_id)); ?></td>
                            <td><?php echo e($appointment->date_of_appointment); ?></td>
                            <td><?php echo e($appointment->time_of_appointment); ?></td>
                            <td><a class="btn btn-circle btn-secondary btn-sm" href="/appointment/<?php echo e($appointment->id); ?>"><i class="fa fa-eye"></i></a></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                          <tr>
                              <td colspan="5">Nuk ka të dhëna</td> </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
<hr class="mb-5">
<table class="table table-bordered"  width="100%" cellspacing="0">
        <h3>Vizitat</h3> <hr>
            <thead class="bg-dark text-light">
              <tr>
                <th>Pacienti</th>
                <th>Dentisti</th>
                <th>Data</th>
                <th>Ora</th>
                <th>Menaxhimi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($visits)>0): ?>  
              <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(App\Pacient::getPacient($visit->pacient_id)); ?></td>
                <td><?php echo e(App\User::getUser($visit->user_id)); ?></td>
                <td><?php echo e($visit->date_of_visit); ?></td>
                <td><?php echo e($visit->time_of_visit); ?></td>
                <td><a class="btn btn-circle btn-secondary btn-sm" href="/visit/<?php echo e($visit->id); ?>"><i class="fa fa-eye"></i></a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                  <td colspan="5">Nuk ka të dhëna</td> </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <hr class="mb-5">
<table class="table table-bordered"  width="100%" cellspacing="0">
        <h3>Trajtimet</h3> <hr>
            <thead class="bg-dark text-light">
              <tr>
                <th>Pacienti</th>
                <th>Data e fillimit</th>
                <th>Kohëzgjatja</th>
                <th>Menaxhimi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($treatments)>0): ?>  
              <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(App\Pacient::getPacient($treatment->pacient_id)); ?></td>
                <td><?php echo e($treatment->starting_date); ?></td>
                <td><?php echo e($treatment->duration); ?></td>
                <td><a class="btn btn-circle btn-secondary btn-sm" href="/treatment/<?php echo e($treatment->id); ?>"><i class="fa fa-eye"></i></a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                  <td colspan="5">Nuk ka të dhëna</td> </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <hr class="mb-5">
<table class="table table-bordered"  width="100%" cellspacing="0">
        <h3>Raporti</h3> <hr>
            <thead class="bg-dark text-light">
              <tr>
                <th>Pacienti</th>
                <th>Trajtimi</th>
                <th>Data</th>
                <th>Menaxhimi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($reports)>0): ?>  
              <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(App\Pacient::getPacient($report->pacient_id)); ?></td>
                <td><a class="btn btn-circle btn-secondary btn-sm" href="/treatment/<?php echo e($report->treatment_id); ?>"><i class="fa fa-syringe"></i></a> <?php echo e(App\Treatment::getStartingDate($report->treatment_id)); ?></td>
                <td><?php echo e($report->created_at); ?></td>
                <td><a class="btn btn-circle btn-secondary btn-sm" href="/report/<?php echo e($report->id); ?>"><i class="fa fa-eye"></i></a></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                  <td colspan="5">Nuk ka të dhëna</td> </tr>
              <?php endif; ?>
            </tbody>
          </table>

       
    </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/pacient/show.blade.php ENDPATH**/ ?>