<?php $__env->startSection('title','Shto Trajtim'); ?>
<?php $__env->startSection('treatment','active'); ?>
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
  <div class="card-body p-0">
    <div class="row">
      <div class="col-lg-5 m-auto d-flex justify-content-center ">
        <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
      </div>
      <div class="col-lg-7">
        <div class="p-5">
          <div class="text-center">
            <h1 class="h4 text-gray-900 mb-4">Shto Trajtim!</h1>
          </div>
          <form class="user"  enctype="multipart/form-data" method="POST" action="<?php echo e(route('treatment.store')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="form-group ">
              <label class="text-xs" for="pacient">Pacienti</label>
              <div class="input-group mb-3">
                  <div class="input-group-prepend">
                      <button class="btn btn-outline-primary" type="button"  data-toggle="modal" data-target="#pacientModal"><i class="fa fa-plus"></i> </button>
                  </div>
                  <input readonly placeholder="Pacienti"  value="<?php echo e(old('pacient')); ?>" class="form-control form-control-user <?php if ($errors->has('pacient-id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pacient-id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> " id="pacient" name="pacient"  />
                  <input  hidden id="pacient-id"   value="<?php echo e(old('pacient-id')); ?>" name="pacient-id"/>
                  <div class="input-group-append">
                      <button type="button"  class="btn btn-outline-danger" onclick="document.getElementById('pacient').value=''; document.getElementById('pacient-id').value='';" >
                        <i class="fa fa-trash"></i>
                      </button>
                    </div>
              </div>
              
              <div class="modal fade" id="pacientModal" tabindex="-1" role="dialog" aria-labelledby="pacientModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="pacientModalLabel">Zgjedh Pacientin</h5>
                      </div>
                      <div class="modal-body mx-2">
                        <table class="table table-bordered table-hover"  width="100%" cellspacing="0" id="searchPacient">
                          <thead class="bg-dark text-light">
                            <tr>
                              <th scope="col">Emri</th>
                              <th scope="col">Mbiemri</th>
                              <th scope="col">Nr Personal</th>
                              <th scope="col">Shto</th>
                            </tr>
                          </thead>
                          <tbody>
                          </tbody>
                        </table>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Mbylle</button>
                      </div>
                    </div>
                  </div>
                </div>
                <?php if($errors->has('pacient-id')): ?>
                <span class="help-block">
                    <strong class="text-danger"><small><?php echo e($errors->first('pacient-id')); ?></small> </strong>
                </span>
            <?php endif; ?>
          </div>
            <div class="form-group ">
                    <label class="text-xs"  for="starting_date">Data e fillimit</label>
                <input id="starting_date" name="Data_e_fillimit" value="<?php echo e(old('Data_e_fillimit')); ?>" required autofocus type="date" class="form-control form-control-user <?php if ($errors->has('Data_e_fillimit')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Data_e_fillimit'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> "  placeholder="Data e fillimit">
                <?php if($errors->has('Data_e_fillimit')): ?>
                                  <span class="help-block">
                                    <strong class="text-danger"><small><?php echo e($errors->first('Data_e_fillimit')); ?></small></strong>
                                  </span>
                              <?php endif; ?>
            </div>
            <div class="form-group ">
                      <label class="text-xs"  for="duration">Kohezgjatjta</label>
            <input type="text" required class="form-control form-control-user <?php if ($errors->has('Kohezgjatja')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Kohezgjatja'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required="" value="<?php echo e(old('Kohezgjatja')); ?>" name="Kohezgjatja" id="duration"  placeholder="Kohezgjatja">
                      <?php if($errors->has('Kohezgjatja')): ?>
                                        <span class="help-block">
                                          <strong class="text-danger"><small><?php echo e($errors->first('Kohezgjatja')); ?></small></strong>
                                        </span>
                                    <?php endif; ?>
              </div>

              <div class="form-group mb-3">
                  <label class="text-xs" for="services">Shërbimet</label>
                  <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <button class="btn btn-outline-primary" type="button"  data-toggle="modal" data-target="#serviceModal"><i class="fa fa-plus"></i> </button>
                  </div>
                  <input  hidden id="service-list"  name="Sherbimet"/>
                <select readonly  multiple placeholder="Shërbimet" class="form-control form-control-user <?php if ($errors->has('Sherbimet')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Sherbimet'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="services" name="services" >
                  </select>
                  <div class="input-group-append">
                      <button type="button" class="btn btn-outline-danger" onclick=" document.getElementById('service-list').value='';
                      document.getElementById('services').options.length = 0;" >
                        <i class="fa fa-trash"></i>
                      </button>
                    </div>
                  </div>
                <div class="modal fade" id="serviceModal" tabindex="-1" role="dialog" aria-labelledby="serviceModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="serviceModalLabel">Zgjedh Shërbimin</h5>
                        </div>
                        <div class="modal-body">
                          <table class="table table-bordered table-hover" id="searchService"  width="100%" cellspacing="0" >
                            <thead class="bg-dark text-light">
                              <tr>
                                <th scope="col">Shërbimi</th>
                                <th scope="col">Qmimi</th>
                                <th scope="col">Zbritja</th>
                                <th scope="col">Shto</th>
                              </tr>
                            </thead>
                            <tbody >
                            </tbody>
                          </table>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Mbylle</button>
                        </div>
                      </div>
                    </div>
                  </div>
              <?php if($errors->has('Sherbimet')): ?>
                                <span class="help-block">
                                  <strong class="text-danger"><small><?php echo e($errors->first('Sherbimet')); ?></small></strong>
                                </span>
              <?php endif; ?>
             
            </div>

            <div class="form-group">
              <label class="text-xs"  for="photo">Grafia</label>
            <input id="logo" type="file" class="form-control <?php if ($errors->has('Foto')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Foto'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="Foto" id="photo" placeholder="Fotoja e faturës" >
                      <?php if($errors->has('Foto')): ?>
                                        <span class="help-block">
                                          <strong class="text-danger"><small><?php echo e($errors->first('Foto')); ?></small></strong>
                                        </span>
                                    <?php endif; ?>
              </div>
              
              
            <div class="form-group">
              <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
              </div>
            </form>
            <hr>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/treatment/create.blade.php ENDPATH**/ ?>