<html>
<head>
	
	<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
	<title></title>
	<style type="text/css">
		body,div,table,thead,tbody,tfoot,tr,th,td,p { font-family:"Calibri"; font-size:x-small }
		a.comment-indicator:hover + comment { background:#ffd; position:absolute; display:block; border:1px solid black; padding:0.5em;  } 
		a.comment-indicator { background:red; display:inline-block; border:1px solid black; width:0.5em; height:0.5em;  } 
		comment { display:none;  } 
        table {width:100%}
	</style>
	
</head>

<body>
<table cellspacing="0" border="0">
	<colgroup width="55"></colgroup>
	<colgroup width="669"></colgroup>
	<colgroup width="373"></colgroup>
	<colgroup width="349"></colgroup>
	<tr>
		<td height="39" align="left" valign=bottom><font color="#000000"><br></font></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype" size=4> Ordinanca  stomatologjike</font></i></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=6><br></font></i></b></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype" size=5><br></font></i></td>
	</tr>
	<tr>
		<td height="39" align="left" valign=bottom><b><i><font face="Palatino Linotype" size=6><br></font></i></b></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=6>  &quot; M E T R O P O L I S &quot;</font></i></b></td>
		<td align="left" valign=bottom><font face="Arial"><br></font></td>
		<td align="left" valign=bottom><font face="Arial"><br></font></td>
	</tr>
	<tr>
		<td height="26" align="left" valign=bottom><font face="Arial"><br></font></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td align="left" valign=bottom><font face="Arial"><br></font></td>
		<td align="left" valign=bottom><font face="Arial"><br></font></td>
	</tr>
	<tr>
		<td height="26" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td align="left" valign=bottom><font face="Arial" size=4 color="#222222">Prizren, Sh.i Lidhjes,8</font></td>
		<td colspan=2 align="center" valign=bottom><b><i><font face="Palatino Linotype" size=4>Shfrytëzuesi i shërbimeve</font></i></b></td>
		</tr>
	<tr>
		<td height="26" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td align="left" valign=bottom><font face="Arial" size=4>Nr. regj: 810982464</font></td>
		<td colspan=2 rowspan=2 align="center" valign=bottom><i><font face="Palatino Linotype"><u><?php echo e($pacient->first_name); ?> <?php echo e($pacient->fathers_name); ?> <?php echo e($pacient->last_name); ?></ul></font></i></td>
		</tr>
	<tr>
		<td height="18" align="left" valign=bottom><font face="Arial"><br></font></td>
		<td align="left" valign=bottom><font face="Arial"><br></font></td>
		</tr>
	<tr>
		<td height="26" align="left" valign=bottom><font face="Arial"><br></font></td>
    <td align="left" valign=bottom><i><font face="Palatino Linotype" size=4>Fatura nr. <u><?php echo e($report->id); ?></ul></font></i></td>
		<td colspan=2 align="center" valign=bottom><i><font face="Palatino Linotype"><u><?php echo e($pacient->personal_number); ?> <?php echo e($pacient->residence); ?> <?php echo e($pacient->city); ?></ul></font></i></td>
		</tr>
	<tr>
		<td height="18" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
	</tr>
	<tr>
		<td height="26" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=bottom><i><font face="Palatino Linotype" size=4>Përshkrimi i punës së kryer</font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=bottom><i><font face="Palatino Linotype" size=4>Dhëmb</font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="center" valign=bottom><i><font face="Palatino Linotype" size=4>Çmimi</font></i></td>
    </tr>
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="26" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom> <i><font face="Palatino Linotype" size=4><br><?php echo e($service->name); ?></font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br><?php echo e($service->price - ($service->price * ($service->discount /100))); ?> €</font></i></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td style="border-top: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000" height="26" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="center" valign=bottom><i><font face="Palatino Linotype" size=4>V  L  E  R  A</font></i></td>
		<td style="border-top: 1px solid #000000; border-bottom: 1px solid #000000" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br></font></i></td>
		<td style="border-top: 2px solid #000000; border-bottom: 2px solid #000000; border-left: 2px solid #000000; border-right: 2px solid #000000" align="left" valign=bottom><i><font face="Palatino Linotype" size=4><br><?php echo e(App\Report::getTotal($report->id)); ?> €</font></i></td>
	</tr>
	<tr>
		<td height="18" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><font color="#000000"><br></font></td>
	</tr>
	<tr>
		<td height="18" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
	</tr>
	<tr>
		<td height="18" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
	</tr>
	<tr>
		<td height="18" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
	</tr>
	<tr>
		<td height="23" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4>P r i z r e n</font></i></b></td>
		<td colspan=2 align="center" valign=bottom><b><i><font face="Palatino Linotype" size=4>Personi i përgjegjës</font></i></b></td>
		</tr>
	<tr>
		<td height="23" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4><br></font></i></b></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4><br></font></i></b></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4><br></font></i></b></td>
	</tr>
	<tr>
		<td height="23" align="left" valign=bottom><i><font face="Palatino Linotype"><br></font></i></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4>Ditë <?php echo e($report->created_at); ?> g.</font></i></b></td>
		<td align="left" valign=bottom><font color="#000000"><br></font></td>
		<td align="left" valign=bottom><b><i><font face="Palatino Linotype" size=4>____________________</font></i></b></td>
	</tr>
</table>
</body>

</html>
<?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/report/download.blade.php ENDPATH**/ ?>