<?php $__env->startSection('title','Kerkimi'); ?>
<?php $__env->startSection('content'); ?>

<!-- Begin Page Content -->
<div class="container-fluid mt-4">

    <!-- Page Heading -->
    <div class="row">
      <div class="col-sm-6">
        <h1 class="h3 mb-4 text-gray-800"><?php echo e($keyword); ?> Kërkimi</h1>
      </div>
      <div class="col-sm-6 ">
        </div>
    </div>
    
    
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Lista e kërkimit</h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                  <th>Emri</th>
                  <th>Mbiemri</th>
                  <th>Numri Personal</th>
                  <th>Data e lindjes</th>
                  <th>Adresa</th>
                  <th>Vendbanimi</th>
                  <th>Menaxhimi</th>
              </tr>
            </thead>
            <tbody>
              <?php if(count($pacients) > 0): ?>
              <?php $__currentLoopData = $pacients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pacient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($pacient->first_name); ?></td>
                <td><?php echo e($pacient->last_name); ?></td>
                <td><?php echo e($pacient->personal_number); ?></td>
                <td><?php echo e($pacient->date_of_birth); ?></td>
                <td><?php echo e($pacient->address); ?></td>
                <td><?php echo e($pacient->residence); ?></td>
                <td>
                  <a href="/pacient/<?php echo e($pacient->id); ?>" class="btn btn-circle btn-secondary"><i class="fa fa-eye"></i></a>
                </td>
                
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                <td colspan="5">Nuk u gjetën pacientë</td>
              </tr>
              <?php endif; ?>
            </tbody>
          </table>
          <?php echo e($pacients->appends(request()->query())->links()); ?>

        </div>
      </div>
    </div>
  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/search.blade.php ENDPATH**/ ?>