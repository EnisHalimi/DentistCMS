<?php $__env->startSection('title','Settings'); ?>
<?php $__env->startSection('dashboard','active'); ?>
<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
      <!-- Nested Row within Card Body -->
      <div class="row">
        <div class="col-lg-5 d-flex justify-content-center ">
        <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
        </div>
        <div class="col-lg-7">
          <div class="p-5">
            <div class="text-center">
              <h1 class="h4 text-gray-900 mb-4">Aranzhimet</h1>
            </div>
            <table class="table table-striped ">
                    <tbody>
                        <tr>
                            <th>Emri i Ordinancës:</th>
                            <td scope="row"><?php echo e($settings->app_name); ?></td>
                        </tr>
                        <tr>
                            <th>Logoja:</th>
                        <td scope="row"><img src="<?php echo e(asset('img/'.$settings->logo.'')); ?>" class="img-fluid" /></td>
                        </tr>
                       
                        <tr>
                            <th>Tema:</th>
                            <td scope="row">
                                <?php if($settings->theme): ?>
                                E errët
                                <?php else: ?>
                                E ndriquar  
                                <?php endif; ?>
                            </td>
                        </tr>
                       
                        </tbody>
                </table>
               
            <hr>
            <a href="settings/edit" class="btn btn-circle btn-primary"><i class="fa fa-pen"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/settings.blade.php ENDPATH**/ ?>