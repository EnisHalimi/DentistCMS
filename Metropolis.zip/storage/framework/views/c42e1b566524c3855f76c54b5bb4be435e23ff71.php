<?php $__env->startSection('title','Shto Termin'); ?>
<?php $__env->startSection('appointment','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-5 m-auto d-flex justify-content-center ">
          <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
          </div>
          <div class="col-lg-7">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Shto Termin!</h1>
              </div>
              <form class="user" method="POST" action="<?php echo e(route('appointment.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                <div class="form-group ">
                    <label class="text-xs" for="pacient">Pacienti</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <button class="btn btn-outline-primary" type="button"  data-toggle="modal" data-target="#pacientModal"><i class="fa fa-plus"></i> </button>
                        </div>
                    <input  placeholder="Pacienti" readonly class="form-control form-control-user <?php if ($errors->has('pacient-id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pacient-id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="pacient" name="pacient"   value="<?php echo e(old('pacient')); ?>" />
                    <input  hidden id="pacient-id"  name="pacient-id"  value="<?php echo e(old('pacient-id')); ?>"/>
                    <div class="input-group-append">
                        <button type="button"  class="btn btn-outline-danger" onclick="document.getElementById('pacient').value=''; document.getElementById('pacient-id').value='';" >
                          <i class="fa fa-trash"></i>
                        </button>
                      </div>
                </div>
                    <div class="modal fade" id="pacientModal" tabindex="-1" role="dialog" aria-labelledby="pacientModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="pacientModalLabel">Zgjedh Pacientin</h5>
                            </div>
                            <div class="modal-body mx-2">
                              <table class="table table-bordered table-hover"  width="100%" cellspacing="0" id="searchPacient">
                                <thead class="bg-dark text-light">
                                  <tr>
                                    <th scope="col">Emri</th>
                                    <th scope="col">Mbiemri</th>
                                    <th scope="col">Nr Personal</th>
                                    <th scope="col">Shto</th>
                                  </tr>
                                </thead>
                                <tbody>
                                </tbody>
                              </table>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Mbylle</button>
                            </div>
                          </div>
                        </div>
                      </div>
                  <?php if($errors->has('pacient-id')): ?>
                                    <span class="help-block">
                                        <strong class="text-danger"><small><?php echo e($errors->first('pacient-id')); ?></small> </strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <div class="form-group ">
                        <label class="text-xs" for="user">Dentisti</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <button class="btn btn-outline-primary" type="button"  data-toggle="modal" data-target="#userModal"><i class="fa fa-plus"></i> </button>
                            </div>
                        <input  placeholder="Dentisti" readonly  value="<?php echo e(old('user')); ?>" class="form-control form-control-user <?php if ($errors->has('user-id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('user-id'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="user" name="user"   />
                        <input  hidden id="user-id"   value="<?php echo e(old('user-id')); ?>" name="user-id"/>
                        <div class="input-group-append">
                            <button type="button"  class="btn btn-outline-danger" onclick="document.getElementById('user').value=''; document.getElementById('user-id').value='';" >
                              <i class="fa fa-trash"></i>
                            </button>
                          </div>
                    </div>
                        <div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="userModalLabel">Zgjedh Dentistin</h5>
                                </div>
                                <div class="modal-body">
                                  <table class="table table-bordered table-hover"  width="100%" cellspacing="0" id="searchUser" >
                                    <thead class="bg-dark text-light">
                                    <tr>
                                    <th>Dentisti</th>
                                    <th>E-Mail</th>
                                    <th>Shto</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                  </table>
                                    
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Mbylle</button>
                                </div>
                              </div>
                            </div>
                          </div> 
                        <?php if($errors->has('user-id')): ?>
                                          <span class="help-block">
                                            <strong class="text-danger"><small><?php echo e($errors->first('user-id')); ?></small></strong>
                                          </span>
                                      <?php endif; ?>
                </div>
                <div class="form-group ">
                        <label class="text-xs"  for="data">Data e Terminit</label>
                        <input type="date"  value="<?php echo e(old('data')); ?>" class="form-control form-control-user <?php if ($errors->has('data')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('data'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required="" name="data" id="data" min="<?php echo e(date('Y-m-d',strtotime('tomorrow'))); ?>" placeholder="Data e Terminit">
                        <?php if($errors->has('data')): ?>
                                          <span class="help-block">
                                            <strong class="text-danger"><small><?php echo e($errors->first('data')); ?></small></strong>
                                          </span>
                                      <?php endif; ?>
                </div>
                
                <div class="form-group">
                        <label class="text-xs"  for="time">Ora e Terminit</label>
                        <select class="form-control form-control-user <?php if ($errors->has('time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('time'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="time" name="time" placeholder="Ora"> 
                          <option>08:00</option>
                          <option>08:30</option>
                          <option>09:00</option>
                          <option>09:30</option>
                          <option>10:00</option>
                          <option>10:30</option>
                          <option>11:00</option>
                          <option>11:30</option>
                          <option>12:00</option>
                          <option>12:30</option>
                          <option>13:00</option>
                          <option>13:30</option>
                          <option>14:00</option>
                          <option>14:30</option>
                          <option>15:00</option>
                          <option>15:30</option>
                          <option>16:00</option>
                          <option>16:30</option>
                          <option>17:00</option>
                          <option>17:30</option>
                          <option>18:00</option>
                          <option>18:30</option>
                          <option>19:00</option>
                          <option>19:30</option>
                        </select>
                        <?php if($errors->has('time')): ?>
                        <span class="help-block">
                          <strong class="text-danger"><small><?php echo e($errors->first('data')); ?></small></strong>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                  <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
                </div>
              </form>
              <hr>
            </div>
          </div>
        </div>
      </div>
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/appointment/create.blade.php ENDPATH**/ ?>