<?php $__env->startSection('title','Shto Perdorues'); ?>
<?php $__env->startSection('user','active'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-5 m-auto d-flex justify-content-center ">
          <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
          </div>
          <div class="col-lg-7">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Shto Përdorues!</h1>
              </div>
              <form class="user" method="POST" action="<?php echo e(route('user.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                <div class="form-group ">
                  <input id="name" name="Emri_dhe_Mbiemri" value="<?php echo e(old('Emri_dhe_Mbiemri')); ?>" required autofocus type="text" class="form-control form-control-user <?php if ($errors->has('Emri_dhe_Mbiemri')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Emri_dhe_Mbiemri'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="Emri dhe Mbiemri">
                  <?php if($errors->has('Emri_dhe_Mbiemri')): ?>
                                    <span class="help-block">
                                        <strong class="text-danger"><small><?php echo e($errors->first('Emri_dhe_Mbiemri')); ?></small></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <div class="form-group">
                  <input  id="email" name="email" value="<?php echo e(old('email')); ?>" required type="email" class="form-control form-control-user <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email Address">
                  <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong class="text-danger"><small>><?php echo e($errors->first('email')); ?></small></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <div class="form-group">
                  <input  id="position" name="Pozita" value="<?php echo e(old('Pozita')); ?>" required type="text" class="form-control form-control-user <?php if ($errors->has('Pozita')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Pozita'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Pozita">
                  <?php if($errors->has('Pozita')): ?>
                                    <span class="help-block">
                                        <strong class="text-danger"><small><?php echo e($errors->first('Pozita')); ?></small></strong>
                                    </span>
                                <?php endif; ?>
                </div>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input id="password" name="password" required type="password" class="form-control form-control-user <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="Password">
                    
                    <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong class="text-danger"><small><?php echo e($errors->first('password')); ?></small></strong>
                                    </span>
                                <?php endif; ?>
                  </div>
                  <div class="col-sm-6">
                    <input id="password-confirm" name="password_confirmation" required type="password" class="form-control form-control-user <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Përsërit Password">
                  </div>
                </div>
                <div class="form-group">
                  <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                    <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
                  </div>
              </form>
              <hr>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/user/create.blade.php ENDPATH**/ ?>