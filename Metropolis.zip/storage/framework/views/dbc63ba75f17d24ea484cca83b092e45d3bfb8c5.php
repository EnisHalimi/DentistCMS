<?php $__env->startSection('title','Ndrysho Settings'); ?>
<?php $__env->startSection('dashboard','active'); ?>
<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
          <div class="row">
            <div class="col-lg-5 m-auto d-flex justify-content-center ">
              <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
            </div>
            <div class="col-lg-7">
              <div class="p-5">
                <div class="text-center">
                  <h1 class="h4 text-gray-900 mb-4">Ndrysho Aranzhimet!</h1>
                </div>
                <form class="user" method="POST"  enctype="multipart/form-data" action="<?php echo e(url('/settings/save')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-group ">
                    <label class="text-xs" for="pacient">Emri i Ordinancës</label>
                    <input id="app_name" name="app_name" value="<?php echo e($settings->app_name); ?>" required type="text" class="form-control form-control-user"  placeholder="Emri i Ordinancës">
                                  
                                  <?php if($errors->has('app_name')): ?>
                                                  <span class="help-block">
                                                      <strong><?php echo e($errors->first('app_name')); ?></strong>
                                                  </span>
                                              <?php endif; ?>
                </div>
                  <div class="form-group ">
                    <label class="text-xs"  for="data">Logoja</label>
                  <input id="logo" type="file" class="form-control" name="logo" placeholder="<?php echo e($settings->logo); ?>" >
                            <?php if($errors->has('logo')): ?>
                                              <span class="help-block">
                                                  <strong><?php echo e($errors->first('logo')); ?></strong>
                                              </span>
                                          <?php endif; ?>
                    </div>
                    <div class="form-group ">
                        <label class="text-xs"  for="data">Tema</label>
                    <select class="form-control form-control-user" id="theme" name="theme" placeholder="Tema">
                        <option <?php if($settings->theme == false): ?> selected <?php else: ?> <?php endif; ?> value="0">E ndriquar</option>
                        <option <?php if($settings->theme == true): ?> selected <?php else: ?> <?php endif; ?> value="1">E errët</option>
                    </select>
                    </div>
                  <div class="form-group">
                    <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                      <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
                    </div>
                  </form>
                  <hr>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/enishalimi/Websites/Metropolis/resources/views/settings/edit.blade.php ENDPATH**/ ?>