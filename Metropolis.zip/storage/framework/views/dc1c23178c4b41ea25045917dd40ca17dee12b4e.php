<?php $__env->startSection('title','Shiko Dalje'); ?>
<?php $__env->startSection('pacient','active'); ?>
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-5 m-auto d-flex justify-content-center ">
                <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
            </div>
        <div class="col-lg-7">
            <div class="p-5">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Të dhënat e daljes</h1>
                </div>
                <table class="table table-striped ">
                        <tbody>
                            <?php if($dalje->type == "Faturë"): ?>
                            <tr>
                                <th>Tipi:</th>
                                <td scope="row"><?php echo e($dalje->type); ?></td>
                            </tr>
                            <tr>
                                <th>Subjekti:</th>
                                <td scope="row"><?php echo e($dalje->subject); ?></td>
                            </tr>
                            <tr>
                                <th>Nr i Faturës:</th>
                                <td scope="row"><?php echo e($dalje->bill_number); ?></td>
                            </tr>
                           
                            <tr>
                                <th>Vlera:</th>
                                <td scope="row"><?php echo e($dalje->value); ?> €</td>
                            </tr>
                            <tr>
                                    <th>Afati:</th>
                                    <td scope="row"><?php echo e($dalje->deadline->format('d/m/Y')); ?></td>
                                </tr>
                            <tr>
                                <th>Foto:</th>
                                <td scope="row"><img src="<?php echo e(asset('img/faturat/'.$dalje->file.'')); ?>" class="img-fluid" /></td></td>
                            </tr>
                            <?php else: ?>
                            <tr>
                                <th>Tipi:</th>
                                <td scope="row"><?php echo e($dalje->type); ?></td>
                            </tr>
                            <tr>
                                <th>Pacienti:</th>
                                <td scope="row"><a class="btn btn-circle btn-secondary btn-sm" href="/pacient/<?php echo e($dalje->pacient_id); ?>"><i class="fa fa-user"></i></a> <?php echo e(App\Pacient::getPacient($dalje->pacient_id)); ?></td>
                            </tr>
                            <tr>
                                <th>Vlera:</th>
                                <td scope="row"><?php echo e($dalje->value); ?> €</td>
                            </tr>
                            <tr>
                                    <th>Afati:</th>
                                    <td scope="row"><?php echo e($dalje->deadline->format('d/m/Y')); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                <hr>
                <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                        <a href="/daljet/<?php echo e($dalje->id); ?>/edit"  class="btn btn-circle btn-primary"><i class="fa fa-pen"></i></a>
                        <button class="btn btn-circle btn-danger" data-toggle="modal" data-target="#fshijModal<?php echo e($dalje->id); ?>"><i class="fa fa-trash"></i></button>
                        <div class="modal fade" id="fshijModal<?php echo e($dalje->id); ?>" tabindex="-1" role="dialog" aria-labelledby="fshijModalLabel<?php echo e($dalje->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="fshijModalLabel<?php echo e($dalje->id); ?>">Fshij Daljen</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        A jeni i sigurtë që doni të vazhdoni?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-circle btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i></button>
                                        <form class="d-inline" method="POST" action="<?php echo e(route('daljet.destroy',$dalje->id)); ?>" accept-charset="UTF-8">
                                            <?php echo e(csrf_field()); ?>

                                            <input name="_method" type="hidden" value="DELETE">
                                            <button type="submit" class="btn btn-circle btn-danger"><i class="fa fa-trash"></i></button>
                                        </form>
                                        
                                    </div>
                                </div>
                            </div>
                        </div> 
            </div>
          </div>

         
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/resources/views/daljet/show.blade.php ENDPATH**/ ?>