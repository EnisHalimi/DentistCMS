<?php $__env->startSection('title','Pacient Register'); ?>
<?php $__env->startSection('pacient','active'); ?>
<?php $__env->startSection('content'); ?>
<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
            <div class="col-lg-5 d-flex justify-content-center ">
                <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
            </div>
        <div class="col-lg-7">
            <div class="p-5">
                <div class="text-center">
                    <h1 class="h4 text-gray-900 mb-4">Shto Pacient!</h1>
                </div>
            <form class="user" method="POST" action="<?php echo e(route('pacient.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group row">
                    <div class="col-sm-4 mb-3 mb-sm-0">
                                  <input id="first_name" name="first_name" required type="text" class="form-control form-control-user"  placeholder="Emri">
                                  
                                  <?php if($errors->has('first_name')): ?>
                                                  <span class="help-block">
                                                      <strong><?php echo e($errors->first('first_name')); ?></strong>
                                                  </span>
                                              <?php endif; ?>
                                </div>
                                <div class="col-sm-4 mb-3 mb-sm-0">
                                        <input id="fathers_name" name="fathers_name" required type="text" class="form-control form-control-user" placeholder="Emri Prindit">
                                        <?php if($errors->has('fathers_name')): ?>
                                                  <span class="help-block">
                                                      <strong><?php echo e($errors->first('fathers_name')); ?></strong>
                                                  </span>
                                              <?php endif; ?>
                                      </div>
                                <div class="col-sm-4">
                                  <input id="last_name" name="last_name" required type="text" class="form-control form-control-user" placeholder="Mbiemri">
                                  <?php if($errors->has('last_name')): ?>
                                                  <span class="help-block">
                                                      <strong><?php echo e($errors->first('last_name')); ?></strong>
                                                  </span>
                                              <?php endif; ?>
                                </div>
                 </div>
                 <div class="form-group row">
                        <div class="col-sm-4 mb-3 mb-sm-0">
                          <input id="personal_number" name="personal_number" required type="text" class="form-control form-control-user"  placeholder="Numri Personal">
                          
                          <?php if($errors->has('personal_number')): ?>
                                          <span class="help-block">
                                              <strong><?php echo e($errors->first('personal_number')); ?></strong>
                                          </span>
                                      <?php endif; ?>
                        </div>
                        <div class="col-sm-4 mb-3 mb-sm-0">
                                <input id="date_of_birth" name="date_of_birth" required  type="date"  class="form-control form-control-user "96>
                                <?php if($errors->has('date_of_birth')): ?>
                                          <span class="help-block">
                                              <strong><?php echo e($errors->first('date_of_birth')); ?></strong>
                                          </span>
                                      <?php endif; ?>
                              </div>
                        <div class="col-sm-4">
                                <div class="custom-control custom-checkbox small">
                                        <input type="radio"  name="gender" value="M" class="custom-control-input" checked id="gender1">
                                        <label class="custom-control-label" for="gender1">Mashkull</label>
                                </div>
                                <div class="custom-control custom-checkbox small">
                                        <input type="radio"  name="gender" value="F"  class="custom-control-input" id="gender2">
                                        <label class="custom-control-label" for="gender2">Femër</label>
                                </div>
                          <?php if($errors->has('gender')): ?>
                                          <span class="help-block">
                                              <strong><?php echo e($errors->first('gender')); ?></strong>
                                          </span>
                                      <?php endif; ?>
                        </div>
                </div>
                <div class="form-group">
                        <input  id="address" name="address"  required type="text" class="form-control form-control-user" placeholder="Adresa">
                        <?php if($errors->has('address')): ?>
                                          <span class="help-block">
                                              <strong><?php echo e($errors->first('address')); ?></strong>
                                          </span>
                                      <?php endif; ?>
                      </div>
                <div class="form-group row">
                        <div class="col-sm-6 mb-3 mb-sm-0">
                          <input id="residence" name="residence" required type="text" class="form-control form-control-user"  placeholder="Vendbanimi">
                          
                          <?php if($errors->has('residence')): ?>
                                          <span class="help-block">
                                              <strong><?php echo e($errors->first('residence')); ?></strong>
                                          </span>
                                      <?php endif; ?>
                        </div>
                        <div class="col-sm-6">
                                <input id="city" name="city" required type="text" class="form-control form-control-user" placeholder="Qyteti">
                                <?php if($errors->has('city')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('city')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                              </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3 mb-sm-0">
                        <input id="phone" name="phone" required type="text" class="form-control form-control-user <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  placeholder="Numri i telefonit">      
                        <?php if($errors->has('phone')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('phone')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-6">
                        <input id="email" name="email"  type="email" class="form-control form-control-user" placeholder="Email">
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                        <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                          <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
                        </div>
              </form>
              <hr>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/resources/views/pacient/create.blade.php ENDPATH**/ ?>