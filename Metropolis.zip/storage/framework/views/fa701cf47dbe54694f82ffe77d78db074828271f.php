<?php $__env->startSection('title','Service Create'); ?>
<?php $__env->startSection('service','active'); ?>
<?php $__env->startSection('content'); ?>

<div class="card o-hidden border-0 shadow-lg my-5">
    <div class="card-body p-0">
      <!-- Nested Row within Card Body -->
      <div class="row">
        <div class="col-lg-5 d-flex justify-content-center ">
        <img src="<?php echo e(App\User::getLogo()); ?>" class="img-fluid" />
        </div>
        <div class="col-lg-7">
          <div class="p-5">
            <div class="text-center">
              <h1 class="h4 text-gray-900 mb-4">Shto Shërbim!</h1>
            </div>
            <form class="user" method="POST" action="<?php echo e(route('services.store')); ?>">
                      <?php echo e(csrf_field()); ?>

              <div class="form-group ">
                    <label class="text-xs"  for="name">Shërbimi</label>
                <input id="name" name="name" value="<?php echo e(old('name')); ?>" required autofocus type="text" class="form-control form-control-user"  placeholder="Shërbimi">
                <?php if($errors->has('name')): ?>
                                  <span class="help-block">
                                      <strong><?php echo e($errors->first('name')); ?></strong>
                                  </span>
                              <?php endif; ?>
              </div>
              <div class="form-group">
                    <label class="text-xs"  for="price">Qmimi</label>
                <input  id="price" name="price" step="any"  value="<?php echo e(old('price')); ?>" required type="number" class="form-control form-control-user" placeholder="Qmimi">
                <?php if($errors->has('price')): ?>
                                  <span class="help-block">
                                      <strong><?php echo e($errors->first('price')); ?></strong>
                                  </span>
                              <?php endif; ?>
              </div>
              <div class="form-group">
                    <label class="text-xs"  for="discount">Zbritja</label>
                <input  id="discount" value="0"  onchange="document.getElementById('discount-text').innerHTML = this.value + ' %';" name="discount" value="<?php echo e(old('discount')); ?>" required type="range" class="form-control form-control-user" min="0" max="100" class="slider"  placeholder="Zbritja">
                <span id='discount-text'>0 %</span>
                <?php if($errors->has('discount')): ?>
                                  <span class="help-block">
                                      <strong><?php echo e($errors->first('discount')); ?></strong>
                                  </span>
                              <?php endif; ?>
              </div>
              <div class="form-group">
                <a class="btn btn-circle btn-secondary" href="<?php echo e(url()->previous()); ?>" ><i class="fa fa-chevron-left"></i></a>
                  <button type="submit"  class="btn btn-circle btn-primary float-right"><i class="fa fa-save"></i></button>
                </div>
            </form>
            <hr>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/resources/views/service/create.blade.php ENDPATH**/ ?>